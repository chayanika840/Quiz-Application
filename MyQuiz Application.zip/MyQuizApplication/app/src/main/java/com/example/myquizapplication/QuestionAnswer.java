package com.example.myquizapplication;

public class QuestionAnswer {
    public static String question[]={
            "Who is known as father of Java Programming Language?",
            "Which provides runtime environment for java byte code to be executed?",
            "Which of these have highest precedence?",
            "Which of these operators is used to allocate memory to array variable in Java?",
            "What feature of OOP has a super-class sub-class concept?"

    };

    public static String choices[][]={
            {"James Gosling","M.P Java","Charel Babbage","Blais Pascal"},
            {"JDK","JVM","JRE","JAVAC"},
            {"()","++","*",">>"},
            {"alloc","malloc","calloc","new"},
            {"Hierarchical Inheritance","Single Level Inheritance","Multiple Inheritance","Multi Level Inheritance"}

    };

    public static String correctAnswers[]={
            "James Gosling",
            "JVM",
            "()",
            "new",
            "Hierarchical Inheritance"

    };
}
